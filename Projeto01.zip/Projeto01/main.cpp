/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.009
 *
 * Created on 6 de maio de 2024, 16:08
 */

#include <cstdlib>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <string>
#include <math.h>

using namespace std;

/* Projeto criado pot Filipe Bessa Carvalho
 * 
 */

//define o tipo a ser usado pela variável veículos
typedef struct{
    string modelo;
    string marca;
    string tipo;
    int ano;
    float km;
    string potencia_do_motor;
    string combustivel;
    string cambio;
    string direcao;
    string cor;
    string portas;
    string placa;
    float valor;   
    bool valido;
} Veiculo;


int main(int argc, char** argv) {
    
    //define o tamanho dos vetores da variável veículos
    int const TAM = 100;
    //taxa de juros média do financiamento
    float const juros = 0.021;
    int i, pos, opcao = 0, total = 0, conta = 0, km = 0;
    float seda = 0, suv = 0, van = 0, pickup = 0, hatch = 0;
    float gasolina = 0, flex = 0, diesel = 0; 
    float min, max, prestacao = 0;
    bool encontrado;
    Veiculo veiculos[TAM];
    string modelo, busca, placamb, placamc;
    
    //seleciona o arquivo veiculos.txt como entrada
    ifstream entrada("veiculos.txt");
    
    cout<<"TAMANHO DO BANCO DE DADOS DEFINIDO COMO: "<<TAM<<endl;
    cout<<"SE HOUVER MAIS VALORES NO ARQUIVO DE TEXTO, APENAS OS PRIMEIROS "<<TAM<<" SERÃO CONSIDERADOS"<<endl;
    
    //modelo recebe o primeiro valor do arquivo para iniciar as comparações
    entrada>>modelo;
    
    //passa pelo arquivo até encontrar a palavra "FIM" na casa dos modelos
    for(i = 0; modelo != "FIM"; i++){
        veiculos[i].modelo = modelo;
        entrada>>veiculos[i].marca;
        entrada>>veiculos[i].tipo;
        entrada>>veiculos[i].ano;
        entrada>>veiculos[i].km;
        entrada>>veiculos[i].potencia_do_motor;
        entrada>>veiculos[i].combustivel;
        entrada>>veiculos[i].cambio;
        entrada>>veiculos[i].direcao;
        entrada>>veiculos[i].cor;
        entrada>>veiculos[i].portas;
        entrada>>veiculos[i].placa;
        entrada>>veiculos[i].valor;
        veiculos[i].valido = true;
        entrada>>modelo;
    }
    
    //fecha o arquivo de entrada
    entrada.close();
    
    //abre um loop para que as operações disponíveis sejam feitas
    do{
        
        //imprime o menu
        cout<<"\t\tMENU -- DIGITE A OPÇÃO DESEJADA"<<endl;
        cout<<"\t(0)SAIR"<<endl;
        cout<<"\t(1)INCLUSÃO DE VEICULO NOVO"<<endl;
        cout<<"\t(2)BUSCA PELA PLACA (EXCLUSÃO OPCIONAL)"<<endl;
        cout<<"\t(3)BUSCA PELO TIPO"<<endl;
        cout<<"\t(4)BUSCA PELO CAMBIO"<<endl;
        cout<<"\t(5)BUSCA POR UMA FAIXA DE VALORES"<<endl;
        cout<<"\t(6)RELATÓRIO DO BANCO DE DADOS"<<endl;
        
        //recebe a escolha
        cin>>opcao;
        
        //confere se a escolha é válida
        //p.s: se um valor de tipo diferente de int for inserido na variável opcao, o código fecha
        if(opcao > 6 || opcao < 0)
            cout<<"VALOR INVÁLIDO! INSIRA UM NÚMERO ENTRE 0 e 6!"<<endl;
        
        //switch com um caso para cada operação
        switch(opcao){
            
            //inclusão de veículo novo
            case 1:
                
                //inicia encontrado como falso
                encontrado = false;
                
                cout<<"INCLUSÃO DE VEÍCULO NOVO: "<<endl;
                
                //os blocos abaixo procuram uma posição válida para o novo veículo
                //procura por uma posição falsa antes do final do arquivo e guarda o seu valor em pos
                for(int j = 0; j < i; j++){
                    if(veiculos[j].valido == false && encontrado == false){
                        pos = j;
                        encontrado = true;
                    } 
                }
                
                //se não houver posição falsa antes do final, o novo veículo é inserido no final dos vetores (pos = i)
                if(encontrado == false){
                    pos = i;
                    i++;
                }
                
                //confere se a posição é válida
                if(pos < TAM){
                    
                    //recebe as informações do novo veículo
                    //p.s: valores inválidos serão aceitos e causarão mensagens de erro em partes do código
                    //p.p.s: em variáveis definidas como float ou int, a inserção de valores inválidos quebra o código
                    cout<<"Um novo veículo será inserido na posição "<<(pos+1)<<endl;
                    cout<<"Insira o modelo: ";
                    cin>>veiculos[pos].modelo;
                    cout<<"Insira a marca: ";
                    cin>>veiculos[pos].marca;
                    cout<<"Insira o tipo: ";
                    cin>>veiculos[pos].tipo;
                    cout<<"Insira o ano de fabricação: ";
                    cin>>veiculos[pos].ano;
                    cout<<"Insira a quilometragem: ";
                    cin>>veiculos[pos].km;
                    cout<<"Insira a potência do motor: ";
                    cin>>veiculos[pos].potencia_do_motor;
                    cout<<"Insira o tipo de combustível: ";
                    cin>>veiculos[pos].combustivel;
                    cout<<"Insira o câmbio: ";
                    cin>>veiculos[pos].cambio;
                    cout<<"Insira a direção: ";
                    cin>>veiculos[pos].direcao;
                    cout<<"Insira a cor: ";
                    cin>>veiculos[pos].cor;
                    cout<<"Insira o número de portas: ";
                    cin>>veiculos[pos].portas;
                    cout<<"Insira a placa: ";
                    cin>>veiculos[pos].placa;
                    cout<<"Insira o valor: ";
                    cin>>veiculos[pos].valor;
                    veiculos[pos].valido = true;

                    cout<<"Carro adicionado com sucesso!"<<endl;

                } else 
                    cout<<"NÃO HÁ ESPAÇO PARA O NOVO VEÍCULO!"<<endl;
                break;
                
            case 2:
                
                //inicia encontrado como falso
                encontrado = false;
                
                cout<<"BUSCA PELA PLACA (EXCLUSÃO OPCIONAL)"<<endl;
                
                //recebe a placa a ser procurada
                //p.s: não garante que a placa inserida seja válida nos padrões brasileiros
                cout<<"Insira a placa a ser procurada: ";
                cin>>busca;
                
                //busca pela placa e caso encontre-a imprime as informações do mesmo
                //caso exista duas posições com a mesma placa, imprime apenas a primeira 
                for(int j = 0; j < i; j++){
                    if(veiculos[j].placa == busca && encontrado == false && veiculos[j].valido == true){
                        
                        cout<<"Veículo encontrado na posição "<<(j+1)<<endl;
                        cout<<veiculos[j].modelo<<" ";
                        cout<<veiculos[j].marca<<" ";
                        cout<<veiculos[j].tipo<<" ";
                        cout<<veiculos[j].ano<<" ";
                        cout<<veiculos[j].km<<" ";
                        cout<<veiculos[j].potencia_do_motor<<" ";
                        cout<<veiculos[j].combustivel<<" ";
                        cout<<veiculos[j].cambio<<" ";
                        cout<<veiculos[j].direcao<<" ";
                        cout<<veiculos[j].cor<<" ";
                        cout<<veiculos[j].portas<<" ";
                        cout<<veiculos[j].placa<<" ";
                        cout<<veiculos[j].valor<<" ";
                        cout<<endl;
                        encontrado = true;
                        //guarda o índice para a exclusão opcional
                        pos = j;
                        
                    }
                }
                
                //confere se um carro foi encontrado, se sim, dá a opção de excluí-lo
                if(encontrado == false){
                    cout<<"Um veículo com a placa especificada não foi encontrado"<<endl;
                } else {
                    cout<<"DIGITE 1 PARA EXCLUIR, QUALQUER OUTRA TECLA PARA CANCELAR"<<endl;
                    cin>>busca;
                    if(busca == "1"){
                        //define a posição como inválida
                        veiculos[pos].valido = false;
                        cout<<"Veículo excluído!"<<endl;
                    }
                }
                
                break;
                
            case 3:
                
                //inicia encontrado como falso
                encontrado = false;
                
                cout<<"BUSCA PELO TIPO"<<endl;
                
                //recebe o tipo a ser procurado
                //p.s: não garante que o valor seja válido
                cout<<"Insira o tipo a ser procurado: ";
                cin>>busca;
                
                for(int j = 0; j < i; j++){
                    
                    //busca por carros do tipo especificado e escreve suas informações
                    if(veiculos[j].tipo == busca && veiculos[j].valido == true){
                        cout<<"Veículo do tipo "<<busca<<" encontrado na posição "<<(j+1)<<endl<<endl;
                        cout<<veiculos[j].modelo<<" ";
                        cout<<veiculos[j].marca<<" ";
                        cout<<veiculos[j].tipo<<" ";
                        cout<<veiculos[j].ano<<" ";
                        cout<<veiculos[j].km<<" ";
                        cout<<veiculos[j].potencia_do_motor<<" ";
                        cout<<veiculos[j].combustivel<<" ";
                        cout<<veiculos[j].cambio<<" ";
                        cout<<veiculos[j].direcao<<" ";
                        cout<<veiculos[j].cor<<" ";
                        cout<<veiculos[j].portas<<" ";
                        cout<<veiculos[j].placa<<" ";
                        cout<<veiculos[j].valor<<" ";
                        cout<<endl;
                        encontrado = true;
                    }
                }
                
                if(encontrado == false)
                    cout<<"Um veículo com o tipo especificado não foi encontrado"<<endl;
                
                
                break;
                
            case 4:
                
                encontrado = false;
                
                cout<<"BUSCA POR CÂMBIO"<<endl;
                
                //p.s: não garante que o valor seja válido
                cout<<"Insira o câmbio a ser procurado: ";
                cin>>busca;
                
                for(int j = 0; j < i; j++){
                    
                    if(veiculos[j].cambio == busca && veiculos[j].valido == true){
                        
                        cout<<"Veículo com câmbio "<<busca<<" encontrado na posição "<<(j+1)<<endl<<endl;
                        cout<<veiculos[j].modelo<<" ";
                        cout<<veiculos[j].marca<<" ";
                        cout<<veiculos[j].tipo<<" ";
                        cout<<veiculos[j].ano<<" ";
                        cout<<veiculos[j].km<<" ";
                        cout<<veiculos[j].potencia_do_motor<<" ";
                        cout<<veiculos[j].combustivel<<" ";
                        cout<<veiculos[j].cambio<<" ";
                        cout<<veiculos[j].direcao<<" ";
                        cout<<veiculos[j].cor<<" ";
                        cout<<veiculos[j].portas<<" ";
                        cout<<veiculos[j].placa<<" ";
                        cout<<veiculos[j].valor<<" ";
                        cout<<endl;
                        encontrado = true;
                        
                    }
                }
                
                if(encontrado == false)
                    cout<<"Um veículo com o câmbio especificado não foi encontrado"<<endl;
                
                
                break;
                
            case 5:
                
                encontrado = false;
                
                cout<<"BUSCA POR FAIXA DE VALORES"<<endl;
                
                //p.s: não garante que o valor seja válido
                //p.p.s: valores diferentes do tipo da variável quebram o código
                cout<<"Insira o valor mínimo do intervalo de busca: ";
                cin>>min;
                
                cout<<"Insira o valor máximo do intervalo de busca: ";
                cin>>max;
                
                for(int j = 0; j < i; j++){
                    
                    if(veiculos[j].valor >= min && veiculos[j].valor <= max && veiculos[j].valido == true){
                        
                        cout<<"Veículo dentro do intervalo encontrado na posição "<<(j+1)<<endl;
                        cout<<veiculos[j].modelo<<" ";
                        cout<<veiculos[j].marca<<" ";
                        cout<<veiculos[j].tipo<<" ";
                        cout<<veiculos[j].ano<<" ";
                        cout<<veiculos[j].km<<" ";
                        cout<<veiculos[j].potencia_do_motor<<" ";
                        cout<<veiculos[j].combustivel<<" ";
                        cout<<veiculos[j].cambio<<" ";
                        cout<<veiculos[j].direcao<<" ";
                        cout<<veiculos[j].cor<<" ";
                        cout<<veiculos[j].portas<<" ";
                        cout<<veiculos[j].placa<<" ";
                        cout<<veiculos[j].valor<<" ";
                        cout<<endl;
                        encontrado = true;
                        
                    }
                }
                
                if(encontrado == false){
                    cout<<"Um veículo dentro do intervalo especificado não foi encontrado"<<endl;
                }
                
                break;
                
            case 6:
                
                //inicia as variáveis para realizar a primeira comparação
                //p.s: caso exista um valor maior que aquele especificado por min nas primeiras posições, ele não será considerado
                max = 0;
                min = 1000000;
                
                //guarda todas as informações relevantes para o relatório
                for(int j = 0; j < i; j++){
                    
                    if(veiculos[j].valido == true){
                        
                        total++;
                        
                        //conta por tipo de combustível
                        if(veiculos[j].combustivel == "Flex")
                            flex++;
                        else
                            if(veiculos[j].combustivel == "Gasolina")
                                gasolina++;
                            else
                                if(veiculos[j].combustivel == "Diesel")
                                    diesel++;
                            
                                else cout<<"ERRO! VALOR INVALIDO DE COMBUSTÍVEL ENCONTRADO NA POSIÇÃO "<<j+1<<endl;
                        
                        //conta por tipo
                        if(veiculos[j].tipo == "Sedã")
                            seda++;
                        else
                            if(veiculos[j].tipo == "Hatch")
                                hatch++;
                            else
                                if(veiculos[j].tipo == "SUV")
                                    suv++;
                                else
                                    if(veiculos[j].tipo == "Van")
                                        van++;
                                    else
                                        if(veiculos[j].tipo == "Pick-up")
                                            pickup++;
                                   
                                        else cout<<"ERRO! VALOR INVALIDO DE TIPO ENCONTRADO NA POSIÇÃO "<<j+1<<endl;
                                 
                        if(veiculos[j].valor < min  && veiculos[j].potencia_do_motor == "1.0"){
                            min = veiculos[j].valor;
                            placamb = veiculos[j].placa;
                        } 
                        
                        if(veiculos[j].valor > max && veiculos[j].direcao == "Hidráulica" && veiculos[j].cambio == "Automático"){
                            max = veiculos[j].valor;
                            placamc = veiculos[j].placa;  
                        }
                        
                        if(veiculos[j].ano < 2019){
                            conta++;
                            km += veiculos[j].km;
                        }
                    } 
                }
                
                //imprime o relatório
                cout<<"\t\tRELATÓRIO DO BANCO DE DADOS"<<endl;
                
                cout<<"\nPORCENTAGEM DE VEÍCULOS POR TIPO:"<<endl;
                cout<<"\n\tSEDÃ: "<<(seda/total)*100.0<<"%"<<endl; 
                cout<<"\tHATCH: "<<(hatch/total)*100.0<<"%"<<endl;
                cout<<"\tSUV: "<<(suv/total)*100.0<<"%"<<endl;
                cout<<"\tVAN: "<<(van/total)*100.0<<"%"<<endl;
                cout<<"\tPICK-UP: "<<(pickup/total)*100.0<<"%"<<endl;
                
                cout<<"\nPORCENTAGEM DE VEÍCULOS POR COMBUSTÍVEL:"<<endl;
                cout<<"\n\tGASOLINA: "<<(gasolina/total)*100.00<<"%"<<endl;
                cout<<"\tDIESEL: "<<(diesel/total)*100.00<<"%"<<endl;
                cout<<"\tFLEX: "<<(flex/total)*100.00<<"%"<<endl;
                
                cout<<"\nINFORMAÇÕES DO VEÍCULO MAIS BARATO COM POTÊNCIA 1.0:"<<endl;
                cout<<"\n\tPLACA: "<<placamb<<endl; //linha 403
                cout<<"\tVALOR: R$"<<min<<endl; //linha 408
                cout<<"\n\tVALOR DO FINANCIAMENTO COM TAXA DE JUROS MENSAL DE "<<juros*100<<"% EM 60 MESES: "<<endl;
                cout<<"\t\tPRESTAÇÃO: R$";
                prestacao = 1 + juros;
                prestacao = pow(prestacao, -60); 
                prestacao = 1 - prestacao;
                prestacao = juros/prestacao;
                prestacao = prestacao*min;
                cout<<prestacao<<endl;
                cout<<"\t\tVALOR TOTAL: R$"<<prestacao*60<<endl;;
                      
                cout<<"\nINFORMAÇÕES DO VEÍCULO MAIS CARO COM DIREÇÃO HIDRÁULICA E CÂMBIO AUTOMÁTICO:"<<endl;
                cout<<"\n\tPLACA: "<<placamc<<endl;
                cout<<"\tVALOR: R$"<<max<<endl;
                cout<<"\tVALOR ESTIMADO DO SEGURO COM BASE NO IPSA (2023): R$"<<max*0.066<<endl;
                
                cout<<"\nINFORMAÇÕES DOS VEÍCULOS COM CINCO ANOS OU MAIS: "<<endl;
                cout<<"\n\tQUANTIDADE: "<<conta<<endl;
                cout<<"\tQUILOMETRAGEM MÉDIA: "<<km/conta<<endl;
                
                break;
                
        }
            
    }while(opcao != 0);
    
    //abre o arquivo para a escrita
    ofstream saida("veiculos.txt");
    
    //insere todas as informações
    for(int j = 0; j < i; j++){
        if(veiculos[j].valido == true){
            saida<<veiculos[j].modelo<<" ";
            saida<<veiculos[j].marca<<" ";
            saida<<veiculos[j].tipo<<" ";
            saida<<veiculos[j].ano<<" ";
            saida<<veiculos[j].km<<" ";
            saida<<veiculos[j].potencia_do_motor<<" ";
            saida<<veiculos[j].combustivel<<" ";
            saida<<veiculos[j].cambio<<" ";
            saida<<veiculos[j].direcao<<" ";
            saida<<veiculos[j].cor<<" ";
            saida<<veiculos[j].portas<<" ";
            saida<<veiculos[j].placa<<" ";
            saida<<veiculos[j].valor<<" ";
            saida<<endl;
        }
    }
    
    //insere FIM no final do arquivo para que ele não cause loop infinito ao ser usado novamente
    saida<<"FIM"<<endl;
    
    saida.close();
            
    cout<<"ALTERAÇÕES SALVAS NO ARQUIVO \"veiculos.txt\"."<<endl;
    
    return 0;
}

