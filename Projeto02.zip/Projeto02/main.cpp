/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Autores: Filipe Carvalho (2024.1.08.009) e Jeann Batista (2024.1.08.014)
 *
 * Created on 11 de junho de 2024, 16:19
 */

#include <stdio.h>
#include <fstream>
#include <iostream>
#include "func.h"

using namespace std;

/* Este algoritmo possui uma série de funções que fazem operações sobre uma
 * imagem em formato pgm.
 */

int main(int argc, char** argv) {
    
    /*SETUP
     */
    string tipo;//tipo da imagem
    int col, lin, tmax;//valores que vem no começo do arquivo .pgm
    
    ifstream img("stanford.pgm");//define o arquivo de entrada
    if(!img.is_open()){//se ele não existir, retorna erro
        cout<<"ERRO: arquivo não existe."<<endl;
        return 1;
    }
    
    /*LEITURA
     */
    img>>tipo;//lê o tipo de arquivo
    if(tipo != "P2"){//se não for P2, retorna erro
        cout<<"ERRO: o tipo de imagem não é aceito."<<endl;
        return 1;
    }
    
    img>>col;
    img>>lin;
    img>>tmax;
    
    Timagem mat;//cria uma matriz para os valores que serão lidos
    
    for(int i = 0; i < lin; i++){//lê todos os valores e guarda na matriz mat
        for(int j = 0; j < col; j++){
            img>>mat[i][j];
        }
    }

    img.close();//fecha o arquivo de entrada
    
    /* OPERAÇÕES
     */
    int op, n;
    do{
        
        cout<<"\nESCOLHA A OPERAÇÃO A SER FEITA NA IMAGEM"<<endl;//menu de operações
        cout<<"\n1.CLAREAR OU ESCURECER\n2.INVERTER\n3.BINARIZAR\n4.ICONIZAR"<<endl;
        cout<<"5.ADICIONAR RUÍDO\n6.SUAVIZAR\n0.SALVAR E FECHAR"<<endl;
        
        cin>>op;
        
        switch(op){
            case 1://clarear ou escurecer
                n = 0;
                cout<<"Insira o valor (valores negativos escurecem a imagem): ";
                cin>>n;
                claridade(mat, lin, col, n);
                cout<<"Operação concluída!"<<endl;
                break;
            case 2://negativo
                negativo(mat, lin, col);
                cout<<"Operação concluída!"<<endl;
                break;
            case 3://binarização
                n = 0;
                cout<<"Insira o valor para a binarização: ";
                cin>>n;
                binariza(mat, lin, col, n);
                cout<<"Operação concluída!"<<endl;
                break;
            case 4://iconização
                iconiza(mat, lin, col, &lin, &col);
                cout<<"Operação concluída!"<<endl;
                break;
            case 5://ruído
                n = 0;
                cout<<"Insira a intensidade do ruído (o número corresponde ao número de pixeis pretos e brancos adicionados): ";
                cin>>n;
                ruido(mat, lin, col, n);
                cout<<"Operação concluída!"<<endl;
                break;
            case 6://suavização
                suaviza(mat, lin, col);
                cout<<"Operação concluída!"<<endl;
                break;
        }
    }while(op != 0);
    
    /* ESCRITA
     */
    ofstream sai("imagemalterada.pgm");//define o arquivo de saída
    
    sai<<tipo<<endl;//registra o tipo
    sai<<col<<" "<<lin<<" "<<endl;//registra as dimensões
    sai<<tmax<<endl;//registra o valor máximo
    
    for(int i = 0; i < lin; i++){//insere todos os valores de mat no arquivo de saída
        for(int j = 0; j < col; j++){
            sai<<mat[i][j]<<" ";
        }
        sai<<endl;
    }
    
    sai.close();//fecha o arquivo de saída
    
    return 0;
}

