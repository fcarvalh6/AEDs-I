/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   func.h
 * Author: 2024.1.08.009
 *
 * Created on 17 de junho de 2024, 16:09
 */

#ifndef FUNC_H
#define FUNC_H

typedef int Timagem[1024][1024];

void claridade(Timagem m, int l, int c, int n);
void negativo(Timagem m, int l, int c);
void binariza(Timagem m, int l, int c, int n);
void iconiza(Timagem m, int l, int c, int *lin, int *col);
void ruido(Timagem m, int l, int c, int qtd);
void suaviza(Timagem m, int l, int c);

#endif /* FUNC_H */

