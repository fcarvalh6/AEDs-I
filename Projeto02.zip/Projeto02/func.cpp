/* Conjunto de operações sobre imagens .pgm
 */

#include "func.h"
#include <time.h>
#include <iostream>

using namespace std;

/* Altera a claridade da imagem somando o argumento n com cada pixel
 * valores positivos tornam a imagem mais clara, enquanto valores negativos
 * tornam-a mais escura.
*/
void claridade(Timagem m, int l, int c, int n){
    for(int i = 0; i < l; i++){ //para cada item da matriz
        for(int j = 0; j < c; j++){//se for um valor positivo
            if(n >= 0){//se a soma não ultrapassar 255
                if(m[i][j] < (255-n)){//somar o valor na posição
                    m[i][j] += n;
                } else
                    m[i][j] = 255;//colocar o valor máximo
            } else
                if(m[i][j] > (n*(-1))){//se a soma não ultrapassarescrever um arquivo-texto de saída para cada operação realizada 0
                    m[i][j] += n;//somar o valor na posição
                } else
                    m[i][j] = 0;//colocar o valor mínimo
        }
    }
}

/* Inverte os valores de cada pixel, obtendo o negativo da imagem.
 */
void negativo(Timagem m, int l, int c){
    for(int i = 0; i < l; i++)//para cada item da matriz
        for(int j = 0; j < c; j++)
            m[i][j] = 255 - m[i][j];//inverter o valor
}

/* Binariza a imagem em relação ao argumento n.
 * Pixels com valores iguais ao argumento n serão definidos como zero.
 */
void binariza(Timagem m, int l, int c, int n){
    for(int i = 0; i < l; i++)//para cada item da matriz
        for(int j = 0; j < c; j++)
            if(m[i][j] > n)//se o valor for maior que o argumento n
                m[i][j] = 255;//colocar o valor máximo
            else
                m[i][j] = 0;//colocar o valor mínimo
}

/* Transforma a imagem num ícone de resolução 64x64.
 */
void iconiza(Timagem m, int l, int c, int *lin, int *col){
    //calculando o tamanho das áreas usadas (c2 e l2 são suas dimensões)
    int c2 = c/64, l2 = l/64, soma = 0;
    int div = l2*c2;//número de itens na área para o cálculo da média
    int tmp[l][c];//matriz temporária criada (se Timagem é usado há um erro de segmentação)
    *lin = 64;//valores de linha e coluna são atualizados
    *col = 64;
    
    for(int i = 0; i < l; i++)//copiando a imagem na matriz temporária
        for(int j = 0; j < c; j++)
            tmp[i][j] = m[i][j];
    
    for(int i = 0; i < l; i += l2)
        for(int j = 0; j < c; j += c2){
            for(int k = i; k < l2+i; k++)
                for(int n = j; n < c2+j; n++)
                    soma += tmp[k][n];//soma dos valores médio da área
            m[i/l2][j/c2] = soma/div;//média de cada área
            soma = 0;
        }
}

/* Aplica ruído "sal e pimenta" à imagem. O argumento qtd determina a quantidade
 * de pontos pretos e brancos colocados na imagem.
 */
void ruido(Timagem m, int l, int c, int qtd){
    srand(time(NULL));
    int x, y;//posições na matriz
    for(int i = 0; i < qtd; i++){//essa é a parte da "pimenta"
        x = rand()%l;//valor aleatório menor que o núḿero de linhas
        y = rand()%c;//valor aleatório menor que o núḿero de colunas
        m[x][y] = 0;//coloca valor mínimo
    }
    for(int i = 0; i < qtd; i++){//essa é a parte do "sal"
        x = rand()%l;//valor aleatório menor que o núḿero de linhas
        y = rand()%c;//valor aleatório menor que o núḿero de colunas
        m[x][y] = 255;//coloca valor máximoescrever um arquivo-texto de saída para cada operação realizada
    }
}

/* Suaviza a imagem por meio de um filtro passa-baixo de 3x3.
 */
void suaviza(Timagem m, int l, int c){
    int soma = 0;
    for(int i = 0; i < l; i++)
        for(int j = 0; j< c; j++){
            for(int k = -1; k < 2; k++)
                for(int n = -1; n < 2; n++)
                    if(i+k >= 0 && j+n >= 0)//impede valores inválidos na matriz (deslocamento negativo)
                        if(k != 0 || j != 0)//impede considerar o pixel central 
                            soma += m[i+k][j+n];//somatório dos valores ao redor do pixel
            m[i][j] = soma/8;//média
            soma = 0;
        }
}